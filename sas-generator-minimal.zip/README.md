# Générateur de Documents SAS

## Démarrage Rapide
1. Ouvrez demo_app.html dans votre navigateur
2. Ou lancez: python3 app_simple.py

## Installation
```bash
pip install flask werkzeug requests
python3 app_simple.py
```

## Accès
- Interface démo: demo_app.html  
- Application: http://localhost:5000

Votre générateur de documents juridiques pour SAS est prêt !
