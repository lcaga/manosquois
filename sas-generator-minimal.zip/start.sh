#!/bin/bash
echo "🚀 Démarrage du Générateur SAS"
pip install flask werkzeug requests --break-system-packages 2>/dev/null || pip install flask werkzeug requests
python3 app_simple.py
